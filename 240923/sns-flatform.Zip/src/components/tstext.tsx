// let num: number = 10;

// num = "hello";

// const fnc = (a: number, b: string): void => {
//   console.log("hello")
// }